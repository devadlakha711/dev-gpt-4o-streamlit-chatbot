GPT-4o streamlit chatbot in Python.

Video reference: https://youtu.be/j2WTq82rUr0
